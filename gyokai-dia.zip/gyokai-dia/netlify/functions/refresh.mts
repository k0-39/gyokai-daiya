import type { Config } from "@netlify/functions";
import { collectAll, readLatest } from "../lib/feeds.mts";

const MIN_INTERVAL_MS = 60 * 1000;

export default async (req: Request) => {
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });
  // Reuse a very recent collection so repeated clicks don't hammer the sources.
  const latest = await readLatest();
  if (latest && Date.now() - new Date(latest.updatedAt).getTime() < MIN_INTERVAL_MS) {
    return Response.json({ ...latest, reused: true }, { headers: { "Cache-Control": "no-store" } });
  }
  const data = await collectAll();
  return Response.json(data, { headers: { "Cache-Control": "no-store" } });
};

export const config: Config = {
  path: "/api/refresh",
};
