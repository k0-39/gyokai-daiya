import type { Config } from "@netlify/functions";
import { collectAll, readLatest } from "../lib/feeds.mts";

export default async () => {
  let data = await readLatest();
  if (!data) data = await collectAll();
  return Response.json(data, { headers: { "Cache-Control": "no-store" } });
};

export const config: Config = {
  path: "/api/news",
};
