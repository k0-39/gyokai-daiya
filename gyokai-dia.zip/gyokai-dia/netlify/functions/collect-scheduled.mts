import type { Config } from "@netlify/functions";
import { collectAll } from "../lib/feeds.mts";

export default async () => {
  const data = await collectAll();
  const ok = data.sources.filter((s) => s.ok).length;
  console.log(`collected: ${ok}/${data.sources.length} sources`);
};

export const config: Config = {
  schedule: "*/15 * * * *",
};
