import { getStore } from "@netlify/blobs";

export type Region = "national" | "kagoshima";

export interface Source {
  id: string;
  name: string;
  region: Region;
  url: string;
  home: string;
  /** keep an item only when this returns true; undefined = keep all */
  filter?: (title: string, link: string) => boolean;
  /** items from this source are road / operation alerts */
  alert?: boolean;
}

export interface NewsItem {
  title: string;
  link: string;
  date: string | null; // ISO
  source: string;
  sourceId: string;
  cat: string;
  important: boolean;
  alert: boolean;
}

export interface SourceStatus {
  id: string;
  name: string;
  home: string;
  region: Region;
  ok: boolean;
  count: number;
  error?: string;
}

export interface NewsData {
  updatedAt: string;
  regions: Record<Region, { items: NewsItem[]; alerts: NewsItem[] }>;
  sources: SourceStatus[];
}

const KAGO_TOPICS =
  /観光|旅行|交通|バス|道路|通行|国道|県道|空港|港|クルーズ|フェリー|鉄道|イベント|祭|インバウンド|宿泊|運休|誘客|ツアー|航路|便/;

export const SOURCES: Source[] = [
  {
    id: "mlit",
    name: "国土交通省 報道発表",
    region: "national",
    url: "https://www.mlit.go.jp/pressrelease.rdf",
    home: "https://www.mlit.go.jp/report/press/",
    filter: (t, l) =>
      /バス|自動車|旅客|運輸|観光|旅行|ホテル|宿泊|空港|航空|鉄道|インバウンド|訪日|運転者/.test(t) ||
      /jidosha|kanko/.test(l),
  },
  {
    id: "travelvoice",
    name: "トラベルボイス",
    region: "national",
    url: "https://www.travelvoice.jp/feed",
    home: "https://www.travelvoice.jp/",
  },
  {
    id: "qsr",
    name: "九州地方整備局 記者発表",
    region: "kagoshima",
    url: "https://www.qsr.mlit.go.jp/nt_list/nt1/rss.xml",
    home: "https://www.qsr.mlit.go.jp/",
    filter: (t) => /鹿児島|大隅|薩摩|霧島|国道3号|国道10号|国道220号|国道225号|国道226号|国道269号/.test(t),
  },
  {
    id: "pref-emergency",
    name: "鹿児島県 緊急情報",
    region: "kagoshima",
    url: "http://www.pref.kagoshima.jp/kinkyuu/emergency.xml",
    home: "https://www.pref.kagoshima.jp/",
    alert: true,
  },
  {
    id: "pref",
    name: "鹿児島県 最新情報",
    region: "kagoshima",
    url: "http://www.pref.kagoshima.jp/saishin/saishin.xml",
    home: "https://www.pref.kagoshima.jp/",
    filter: (t) => KAGO_TOPICS.test(t),
  },
  {
    id: "city-emergency",
    name: "鹿児島市 緊急・災害情報",
    region: "kagoshima",
    url: "https://www.city.kagoshima.lg.jp/kinkyu/kinkyu_saigai.xml",
    home: "https://www.city.kagoshima.lg.jp/",
    alert: true,
  },
  {
    id: "city-kanko",
    name: "鹿児島市 観光新着",
    region: "kagoshima",
    url: "https://www.city.kagoshima.lg.jp/shinchaku/kanko_shinchaku.xml",
    home: "https://www.city.kagoshima.lg.jp/",
  },
  {
    id: "city",
    name: "鹿児島市 新着情報",
    region: "kagoshima",
    url: "https://www.city.kagoshima.lg.jp/shinchaku/shinchaku.xml",
    home: "https://www.city.kagoshima.lg.jp/",
    filter: (t) => KAGO_TOPICS.test(t),
  },
];

function decodeEntities(s: string): string {
  return s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/<[^>]+>/g, "")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim();
}

function tag(block: string, names: string[]): string | null {
  for (const n of names) {
    const m = block.match(new RegExp(`<${n}(?:\\s[^>]*)?>([\\s\\S]*?)</${n}>`, "i"));
    if (m) return m[1];
  }
  return null;
}

function toIso(raw: string | null): string | null {
  if (!raw) return null;
  const d = new Date(decodeEntities(raw));
  return isNaN(d.getTime()) ? null : d.toISOString();
}

export function parseFeed(xml: string, base?: string): { title: string; link: string; date: string | null }[] {
  const blocks = xml.match(/<(item|entry)(?:\s[^>]*)?>[\s\S]*?<\/\1>/gi) ?? [];
  const out: { title: string; link: string; date: string | null }[] = [];
  for (const b of blocks) {
    const title = decodeEntities(tag(b, ["title"]) ?? "");
    let link = decodeEntities(tag(b, ["link"]) ?? "");
    if (!link) {
      const href = b.match(/<link[^>]*href="([^"]+)"/i);
      if (href) link = href[1];
    }
    if (!link) {
      const about = b.match(/rdf:about="([^"]+)"/i);
      if (about) link = about[1];
    }
    const date = toIso(tag(b, ["pubDate", "dc:date", "updated", "published"]));
    if (link && base) {
      try { link = new URL(link, base).toString(); } catch { link = ""; }
    }
    if (title && /^https?:\/\//.test(link)) out.push({ title, link, date });
  }
  return out;
}

function decodeBody(buf: ArrayBuffer, contentType: string | null): string {
  const head = new TextDecoder("latin1").decode(buf.slice(0, 200));
  const enc =
    head.match(/encoding=["']([^"']+)["']/i)?.[1] ??
    contentType?.match(/charset=([^;\s]+)/i)?.[1] ??
    "utf-8";
  try {
    return new TextDecoder(enc.toLowerCase()).decode(buf);
  } catch {
    return new TextDecoder("utf-8").decode(buf);
  }
}

export function categorize(title: string): string {
  if (/行政処分|法改正|省令|告示|公示|制度|予算|規制|監査|通達|条例|改正/.test(title)) return "行政・制度";
  if (/貸切|バス|運転者|乗務員|旅客自動車/.test(title)) return "貸切バス";
  if (/通行止|国道|県道|道路|鉄道|運休|運転再開|新幹線|JR|空港|航空|就航|フェリー|航路|渋滞|交通規制/.test(title)) return "交通・道路";
  if (/インバウンド|訪日|外国人|クルーズ|免税|JNTO|海外/.test(title)) return "インバウンド";
  if (/統計|調査結果|万人|前年比|速報|ランキング|決算/.test(title)) return "統計";
  return "旅行・観光";
}

function isImportant(title: string): boolean {
  return /行政処分|通行止|全面|運休|欠航|義務|改正|災害|警報|緊急/.test(title);
}

async function fetchSource(src: Source): Promise<NewsItem[]> {
  const res = await fetch(src.url, {
    headers: { "User-Agent": "GyokaiDiaNewsBot/1.0 (+headline aggregator)", Accept: "application/rss+xml, application/xml, text/xml, */*" },
    signal: AbortSignal.timeout(7000),
    redirect: "follow",
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const xml = decodeBody(await res.arrayBuffer(), res.headers.get("content-type"));
  return parseFeed(xml, src.url)
    .filter((e) => !src.filter || src.filter(e.title, e.link))
    .slice(0, 30)
    .map((e) => ({
      title: e.title,
      link: e.link,
      date: e.date,
      source: src.name,
      sourceId: src.id,
      cat: categorize(e.title),
      important: src.alert ? true : isImportant(e.title),
      alert: !!src.alert,
    }));
}

const ALERT_WINDOW_MS = 3 * 24 * 60 * 60 * 1000;

export async function collectAll(): Promise<NewsData> {
  const results = await Promise.allSettled(SOURCES.map(fetchSource));
  const sources: SourceStatus[] = [];
  const byRegion: Record<Region, NewsItem[]> = { national: [], kagoshima: [] };

  results.forEach((r, i) => {
    const src = SOURCES[i];
    if (r.status === "fulfilled") {
      byRegion[src.region].push(...r.value);
      sources.push({ id: src.id, name: src.name, home: src.home, region: src.region, ok: true, count: r.value.length });
    } else {
      sources.push({
        id: src.id, name: src.name, home: src.home, region: src.region, ok: false, count: 0,
        error: String((r.reason as Error)?.message ?? r.reason).slice(0, 120),
      });
    }
  });

  const now = Date.now();
  const regions = {} as NewsData["regions"];
  for (const region of ["national", "kagoshima"] as Region[]) {
    const seen = new Set<string>();
    const items = byRegion[region]
      .filter((n) => (seen.has(n.link) ? false : (seen.add(n.link), true)))
      .sort((a, b) => (b.date ?? "").localeCompare(a.date ?? ""))
      .slice(0, 50);
    const alerts =
      region === "kagoshima"
        ? items.filter(
            (n) =>
              (n.alert || (n.cat === "交通・道路" && n.important)) &&
              (!n.date || now - new Date(n.date).getTime() < ALERT_WINDOW_MS),
          ).slice(0, 6)
        : [];
    regions[region] = { items, alerts };
  }

  const data: NewsData = { updatedAt: new Date().toISOString(), regions, sources };

  // Keep the previous list for a source that failed this time, so one outage doesn't empty the page.
  const store = getStore({ name: "news", consistency: "strong" });
  const prev = (await store.get("latest", { type: "json" })) as NewsData | null;
  if (prev) {
    for (const s of sources.filter((s) => !s.ok)) {
      const old = prev.regions[s.region].items.filter((n) => n.sourceId === s.id);
      if (old.length) {
        const merged = [...data.regions[s.region].items, ...old]
          .sort((a, b) => (b.date ?? "").localeCompare(a.date ?? ""))
          .slice(0, 50);
        data.regions[s.region].items = merged;
      }
    }
  }
  await store.setJSON("latest", data);
  return data;
}

export async function readLatest(): Promise<NewsData | null> {
  const store = getStore({ name: "news", consistency: "strong" });
  return (await store.get("latest", { type: "json" })) as NewsData | null;
}
